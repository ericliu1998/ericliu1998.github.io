This is a sample notification DLL to be used by ThinApp packages.
It allows you to override the AppSync settings that were present
in the original Package.ini file. To do that, you need to create
a file Overrides.ini in the same directory as your ThinApp
executable and add any AppSync overrides to it, e.g. 

[BuildOptions]
AppSyncURL=http://www.example.com/my/update/Package.dat

Any AppSync settings not overriden in your Overrides.ini file
will keep their original values from Package.ini.

To activate this DLL, add a line to Package.ini in the BuildOptions
section:

[BuildOptions]
NotificationDlls=RedirAppSync.dll

and then on your deployment machine make sure RedirAppSync.dll is
somewhere on the PATH. Alternatively, you can copy RedirAppSync.dll
to the %SystemSystem% directory of your project (you still need the
NotificationDlls line in Package.ini though).