

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0622 */
/* at Mon Jan 18 19:14:07 2038
 */
/* Compiler settings for ThinAppSDK.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0622 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */


#ifndef __ThinAppSDK_h__
#define __ThinAppSDK_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IThinApp_Packages_FWD_DEFINED__
#define __IThinApp_Packages_FWD_DEFINED__
typedef interface IThinApp_Packages IThinApp_Packages;

#endif 	/* __IThinApp_Packages_FWD_DEFINED__ */


#ifndef __IThinApp_VFolder_FWD_DEFINED__
#define __IThinApp_VFolder_FWD_DEFINED__
typedef interface IThinApp_VFolder IThinApp_VFolder;

#endif 	/* __IThinApp_VFolder_FWD_DEFINED__ */


#ifndef __IThinApp_VFolders_FWD_DEFINED__
#define __IThinApp_VFolders_FWD_DEFINED__
typedef interface IThinApp_VFolders IThinApp_VFolders;

#endif 	/* __IThinApp_VFolders_FWD_DEFINED__ */


#ifndef __IThinApp_VRegKeys_FWD_DEFINED__
#define __IThinApp_VRegKeys_FWD_DEFINED__
typedef interface IThinApp_VRegKeys IThinApp_VRegKeys;

#endif 	/* __IThinApp_VRegKeys_FWD_DEFINED__ */


#ifndef __IThinApp_VFile_FWD_DEFINED__
#define __IThinApp_VFile_FWD_DEFINED__
typedef interface IThinApp_VFile IThinApp_VFile;

#endif 	/* __IThinApp_VFile_FWD_DEFINED__ */


#ifndef __IThinApp_VFiles_FWD_DEFINED__
#define __IThinApp_VFiles_FWD_DEFINED__
typedef interface IThinApp_VFiles IThinApp_VFiles;

#endif 	/* __IThinApp_VFiles_FWD_DEFINED__ */


#ifndef __IThinApp_VFileSystemObject_FWD_DEFINED__
#define __IThinApp_VFileSystemObject_FWD_DEFINED__
typedef interface IThinApp_VFileSystemObject IThinApp_VFileSystemObject;

#endif 	/* __IThinApp_VFileSystemObject_FWD_DEFINED__ */


#ifndef __IThinApp_VRegValue_FWD_DEFINED__
#define __IThinApp_VRegValue_FWD_DEFINED__
typedef interface IThinApp_VRegValue IThinApp_VRegValue;

#endif 	/* __IThinApp_VRegValue_FWD_DEFINED__ */


#ifndef __IThinApp_VRegValues_FWD_DEFINED__
#define __IThinApp_VRegValues_FWD_DEFINED__
typedef interface IThinApp_VRegValues IThinApp_VRegValues;

#endif 	/* __IThinApp_VRegValues_FWD_DEFINED__ */


#ifndef __IThinApp_VRegKey_FWD_DEFINED__
#define __IThinApp_VRegKey_FWD_DEFINED__
typedef interface IThinApp_VRegKey IThinApp_VRegKey;

#endif 	/* __IThinApp_VRegKey_FWD_DEFINED__ */


#ifndef __IThinApp_VRegKey2_FWD_DEFINED__
#define __IThinApp_VRegKey2_FWD_DEFINED__
typedef interface IThinApp_VRegKey2 IThinApp_VRegKey2;

#endif 	/* __IThinApp_VRegKey2_FWD_DEFINED__ */


#ifndef __IThinApp_VRegistryObject_FWD_DEFINED__
#define __IThinApp_VRegistryObject_FWD_DEFINED__
typedef interface IThinApp_VRegistryObject IThinApp_VRegistryObject;

#endif 	/* __IThinApp_VRegistryObject_FWD_DEFINED__ */


#ifndef __IThinApp_Option_FWD_DEFINED__
#define __IThinApp_Option_FWD_DEFINED__
typedef interface IThinApp_Option IThinApp_Option;

#endif 	/* __IThinApp_Option_FWD_DEFINED__ */


#ifndef __IThinApp_Options_FWD_DEFINED__
#define __IThinApp_Options_FWD_DEFINED__
typedef interface IThinApp_Options IThinApp_Options;

#endif 	/* __IThinApp_Options_FWD_DEFINED__ */


#ifndef __IThinApp_Package_FWD_DEFINED__
#define __IThinApp_Package_FWD_DEFINED__
typedef interface IThinApp_Package IThinApp_Package;

#endif 	/* __IThinApp_Package_FWD_DEFINED__ */


#ifndef __IThinApp_Package2_FWD_DEFINED__
#define __IThinApp_Package2_FWD_DEFINED__
typedef interface IThinApp_Package2 IThinApp_Package2;

#endif 	/* __IThinApp_Package2_FWD_DEFINED__ */


#ifndef __IThinApp_Management_FWD_DEFINED__
#define __IThinApp_Management_FWD_DEFINED__
typedef interface IThinApp_Management IThinApp_Management;

#endif 	/* __IThinApp_Management_FWD_DEFINED__ */


#ifndef __IThinApp_Management2_FWD_DEFINED__
#define __IThinApp_Management2_FWD_DEFINED__
typedef interface IThinApp_Management2 IThinApp_Management2;

#endif 	/* __IThinApp_Management2_FWD_DEFINED__ */


#ifndef __CThinApp_Management_FWD_DEFINED__
#define __CThinApp_Management_FWD_DEFINED__

#ifdef __cplusplus
typedef class CThinApp_Management CThinApp_Management;
#else
typedef struct CThinApp_Management CThinApp_Management;
#endif /* __cplusplus */

#endif 	/* __CThinApp_Management_FWD_DEFINED__ */


#ifndef __IThinstallLegacyApi_FWD_DEFINED__
#define __IThinstallLegacyApi_FWD_DEFINED__
typedef interface IThinstallLegacyApi IThinstallLegacyApi;

#endif 	/* __IThinstallLegacyApi_FWD_DEFINED__ */


#ifndef __CThinstallLegacyApi_FWD_DEFINED__
#define __CThinstallLegacyApi_FWD_DEFINED__

#ifdef __cplusplus
typedef class CThinstallLegacyApi CThinstallLegacyApi;
#else
typedef struct CThinstallLegacyApi CThinstallLegacyApi;
#endif /* __cplusplus */

#endif 	/* __CThinstallLegacyApi_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 


/* interface __MIDL_itf_ThinAppSDK_0000_0000 */
/* [local] */ 

#define FACILITY_THINAPPSDK 0xc42
#define MAKE_THINAPPSDKHR(Sev, Code) MAKE_HRESULT((Sev), FACILITY_THINAPPSDK, (Code))
#define MAKE_THINAPPSDKHR_ERR(Code)  MAKE_THINAPPSDKHR(SEVERITY_ERROR, (Code))
#define THINAPPSDK_ERR_UNINSTALLED           MAKE_THINAPPSDKHR_ERR(0x0001)
#define THINAPPSDK_ERR_INTERNAL_API_FAILED   MAKE_THINAPPSDKHR_ERR(0x0002)
#define THINAPPSDK_ERR_PACKAGE_TYPE_MISMATCH MAKE_THINAPPSDKHR_ERR(0x0003)
#define THINAPPSDK_ERR_VERIFY_TOO_SMALL      MAKE_THINAPPSDKHR_ERR(0x0004)
#define THINAPPSDK_ERR_APPSYNC_FAILED        MAKE_THINAPPSDKHR_ERR(0x0005)
#define THINAPPSDK_ERR_NO_PERUSER_THINDIRECT MAKE_THINAPPSDKHR_ERR(0x0006)


extern RPC_IF_HANDLE __MIDL_itf_ThinAppSDK_0000_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_ThinAppSDK_0000_0000_v0_0_s_ifspec;


#ifndef __ThinAppSDK_LIBRARY_DEFINED__
#define __ThinAppSDK_LIBRARY_DEFINED__

/* library ThinAppSDK */
/* [version][helpstring][uuid] */ 

typedef /* [public] */ 
enum tagTHINAPP_TYPE
    {
        THINAPP_TYPE_UNKNOWN	= 0,
        THINAPP_TYPE_MAIN_DATA_CONTAINER	= 1,
        THINAPP_TYPE_SHORTCUT_EXE	= 2,
        THINAPP_TYPE_THICK_MSI	= 3,
        THINAPP_TYPE_THIN_MSI	= 4,
        THINAPP_TYPE_OLD_MSI	= 5
    } 	THINAPP_TYPE;

typedef /* [public] */ 
enum tagTHINAPP_HASH_TYPE
    {
        THINAPP_HASH_TYPE_MD5	= 0,
        THINAPP_HASH_TYPE_SHA1	= 1
    } 	THINAPP_HASH_TYPE;

typedef /* [public] */ 
enum tagTHINAPP_REGISTER_FLAGS
    {
        THINAPP_REGISTER_PERUSER	= 1,
        THINAPP_REGISTER_NOARP	= 2,
        THINAPP_REGISTER_KEEPUNAUTHORIZED	= 4,
        THINAPP_REGISTER_REREGISTER	= 8,
        THINAPP_REGISTER_NODESKTOPREFRESH	= 32
    } 	THINAPP_REGISTER_FLAGS;

typedef /* [public] */ 
enum tagTHINAPP_UNREGISTER_FLAGS
    {
        THINAPP_UNREGISTER_QUIET	= 16
    } 	THINAPP_UNREGISTER_FLAGS;

typedef /* [public] */ 
enum tagTHINAPP_APPSYNC_FLAGS
    {
        THINAPP_APPSYNC_SHOW_PROGRESS	= 1
    } 	THINAPP_APPSYNC_FLAGS;

typedef /* [public] */ 
enum tagTHINAPP_VERIFYCONTENTS_TYPE
    {
        THINAPP_VERIFYCONTENTS_EXACT	= 1,
        THINAPP_VERIFYCONTENTS_REGEXP	= 2
    } 	THINAPP_VERIFYCONTENTS_TYPE;





typedef /* [public] */ 
enum tagIsolationModeType
    {
        IsolationWriteCopy	= 1,
        IsolationMerged	= 2,
        IsolationFull	= 3,
        IsolationSandboxOnly	= 4
    } 	IsolationModeType;

typedef /* [public] */ struct tagThinstallPackageInfo
    {
    DWORD BuildVersionNumber;
    DWORD TotalOptions;
    LPCWSTR *OptionNames;
    LPCWSTR *OptionValues;
    } 	ThinstallPackageInfo;

typedef /* [public] */ 
enum tagSandboxStatusFlags
    {
        MachineAppLocalSandboxFound	= 1,
        AppLocalSandboxFound	= 2,
        GlobalMachineLocalSandboxFound	= 4,
        GlobalLocalSandboxFound	= 8,
        MachineSandboxFound	= 16,
        UserSandboxFound	= 32,
        ActiveSandboxIsLocked	= 64
    } 	SandboxStatusFlags;


EXTERN_C const IID LIBID_ThinAppSDK;

#ifndef __IThinApp_Packages_INTERFACE_DEFINED__
#define __IThinApp_Packages_INTERFACE_DEFINED__

/* interface IThinApp_Packages */
/* [object][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_Packages;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6317B341-4E59-464D-B42A-AEC9D416C2F6")
    IThinApp_Packages : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ const VARIANT varIndex,
            /* [retval][out] */ IThinApp_Package **pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_length( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [hidden][restricted][id][propget] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown **pVal) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_PackagesVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_Packages * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_Packages * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_Packages * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_Packages * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_Packages * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_Packages * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_Packages * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IThinApp_Packages * This,
            /* [in] */ const VARIANT varIndex,
            /* [retval][out] */ IThinApp_Package **pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IThinApp_Packages * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_length )( 
            IThinApp_Packages * This,
            /* [retval][out] */ long *pVal);
        
        /* [hidden][restricted][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get__NewEnum )( 
            IThinApp_Packages * This,
            /* [retval][out] */ IUnknown **pVal);
        
        END_INTERFACE
    } IThinApp_PackagesVtbl;

    interface IThinApp_Packages
    {
        CONST_VTBL struct IThinApp_PackagesVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_Packages_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_Packages_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_Packages_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_Packages_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_Packages_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_Packages_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_Packages_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_Packages_get_Item(This,varIndex,pVal)	\
    ( (This)->lpVtbl -> get_Item(This,varIndex,pVal) ) 

#define IThinApp_Packages_get_Count(This,pVal)	\
    ( (This)->lpVtbl -> get_Count(This,pVal) ) 

#define IThinApp_Packages_get_length(This,pVal)	\
    ( (This)->lpVtbl -> get_length(This,pVal) ) 

#define IThinApp_Packages_get__NewEnum(This,pVal)	\
    ( (This)->lpVtbl -> get__NewEnum(This,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_Packages_INTERFACE_DEFINED__ */


#ifndef __IThinApp_VFolder_INTERFACE_DEFINED__
#define __IThinApp_VFolder_INTERFACE_DEFINED__

/* interface IThinApp_VFolder */
/* [object][nonextensible][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_VFolder;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("8601A548-D939-4BEC-85C1-0D640DE71B4C")
    IThinApp_VFolder : public IDispatch
    {
    public:
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Attributes( 
            /* [retval][out] */ long *Attributes) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_DateCreated( 
            /* [retval][out] */ DATE *DateCreated) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_DateLastAccessed( 
            /* [retval][out] */ DATE *DateLastAccessed) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_DateLastModified( 
            /* [retval][out] */ DATE *DateLastModified) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Files( 
            /* [retval][out] */ IThinApp_VFiles **Files) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_IsRootFolder( 
            /* [retval][out] */ boolean *IsRootFolder) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR *Name) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ParentFolder( 
            /* [retval][out] */ IThinApp_VFolder **ParentFolder) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Path( 
            /* [retval][out] */ BSTR *Path) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ShortName( 
            /* [retval][out] */ BSTR *ShortName) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ShortPath( 
            /* [retval][out] */ BSTR *ShortPath) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Size( 
            /* [retval][out] */ MIDL_uhyper *Size) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_SubFolders( 
            /* [retval][out] */ IThinApp_VFolders **SubFolders) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetFilesByExtension( 
            /* [in] */ BSTR Extension,
            /* [retval][out] */ IThinApp_VFiles **Files) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_VFolderVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_VFolder * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_VFolder * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_VFolder * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_VFolder * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_VFolder * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_VFolder * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_VFolder * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Attributes )( 
            IThinApp_VFolder * This,
            /* [retval][out] */ long *Attributes);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_DateCreated )( 
            IThinApp_VFolder * This,
            /* [retval][out] */ DATE *DateCreated);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_DateLastAccessed )( 
            IThinApp_VFolder * This,
            /* [retval][out] */ DATE *DateLastAccessed);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_DateLastModified )( 
            IThinApp_VFolder * This,
            /* [retval][out] */ DATE *DateLastModified);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Files )( 
            IThinApp_VFolder * This,
            /* [retval][out] */ IThinApp_VFiles **Files);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_IsRootFolder )( 
            IThinApp_VFolder * This,
            /* [retval][out] */ boolean *IsRootFolder);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Name )( 
            IThinApp_VFolder * This,
            /* [retval][out] */ BSTR *Name);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ParentFolder )( 
            IThinApp_VFolder * This,
            /* [retval][out] */ IThinApp_VFolder **ParentFolder);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Path )( 
            IThinApp_VFolder * This,
            /* [retval][out] */ BSTR *Path);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ShortName )( 
            IThinApp_VFolder * This,
            /* [retval][out] */ BSTR *ShortName);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ShortPath )( 
            IThinApp_VFolder * This,
            /* [retval][out] */ BSTR *ShortPath);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
            IThinApp_VFolder * This,
            /* [retval][out] */ MIDL_uhyper *Size);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_SubFolders )( 
            IThinApp_VFolder * This,
            /* [retval][out] */ IThinApp_VFolders **SubFolders);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetFilesByExtension )( 
            IThinApp_VFolder * This,
            /* [in] */ BSTR Extension,
            /* [retval][out] */ IThinApp_VFiles **Files);
        
        END_INTERFACE
    } IThinApp_VFolderVtbl;

    interface IThinApp_VFolder
    {
        CONST_VTBL struct IThinApp_VFolderVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_VFolder_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_VFolder_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_VFolder_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_VFolder_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_VFolder_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_VFolder_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_VFolder_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_VFolder_get_Attributes(This,Attributes)	\
    ( (This)->lpVtbl -> get_Attributes(This,Attributes) ) 

#define IThinApp_VFolder_get_DateCreated(This,DateCreated)	\
    ( (This)->lpVtbl -> get_DateCreated(This,DateCreated) ) 

#define IThinApp_VFolder_get_DateLastAccessed(This,DateLastAccessed)	\
    ( (This)->lpVtbl -> get_DateLastAccessed(This,DateLastAccessed) ) 

#define IThinApp_VFolder_get_DateLastModified(This,DateLastModified)	\
    ( (This)->lpVtbl -> get_DateLastModified(This,DateLastModified) ) 

#define IThinApp_VFolder_get_Files(This,Files)	\
    ( (This)->lpVtbl -> get_Files(This,Files) ) 

#define IThinApp_VFolder_get_IsRootFolder(This,IsRootFolder)	\
    ( (This)->lpVtbl -> get_IsRootFolder(This,IsRootFolder) ) 

#define IThinApp_VFolder_get_Name(This,Name)	\
    ( (This)->lpVtbl -> get_Name(This,Name) ) 

#define IThinApp_VFolder_get_ParentFolder(This,ParentFolder)	\
    ( (This)->lpVtbl -> get_ParentFolder(This,ParentFolder) ) 

#define IThinApp_VFolder_get_Path(This,Path)	\
    ( (This)->lpVtbl -> get_Path(This,Path) ) 

#define IThinApp_VFolder_get_ShortName(This,ShortName)	\
    ( (This)->lpVtbl -> get_ShortName(This,ShortName) ) 

#define IThinApp_VFolder_get_ShortPath(This,ShortPath)	\
    ( (This)->lpVtbl -> get_ShortPath(This,ShortPath) ) 

#define IThinApp_VFolder_get_Size(This,Size)	\
    ( (This)->lpVtbl -> get_Size(This,Size) ) 

#define IThinApp_VFolder_get_SubFolders(This,SubFolders)	\
    ( (This)->lpVtbl -> get_SubFolders(This,SubFolders) ) 

#define IThinApp_VFolder_GetFilesByExtension(This,Extension,Files)	\
    ( (This)->lpVtbl -> GetFilesByExtension(This,Extension,Files) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_VFolder_INTERFACE_DEFINED__ */


#ifndef __IThinApp_VFolders_INTERFACE_DEFINED__
#define __IThinApp_VFolders_INTERFACE_DEFINED__

/* interface IThinApp_VFolders */
/* [object][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_VFolders;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B498C448-05A3-4d5b-9B4E-FB8427DD9E2D")
    IThinApp_VFolders : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ const VARIANT varIndex,
            /* [retval][out] */ IThinApp_VFolder **pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_length( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [hidden][restricted][id][propget] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown **pVal) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_VFoldersVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_VFolders * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_VFolders * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_VFolders * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_VFolders * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_VFolders * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_VFolders * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_VFolders * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IThinApp_VFolders * This,
            /* [in] */ const VARIANT varIndex,
            /* [retval][out] */ IThinApp_VFolder **pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IThinApp_VFolders * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_length )( 
            IThinApp_VFolders * This,
            /* [retval][out] */ long *pVal);
        
        /* [hidden][restricted][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get__NewEnum )( 
            IThinApp_VFolders * This,
            /* [retval][out] */ IUnknown **pVal);
        
        END_INTERFACE
    } IThinApp_VFoldersVtbl;

    interface IThinApp_VFolders
    {
        CONST_VTBL struct IThinApp_VFoldersVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_VFolders_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_VFolders_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_VFolders_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_VFolders_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_VFolders_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_VFolders_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_VFolders_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_VFolders_get_Item(This,varIndex,pVal)	\
    ( (This)->lpVtbl -> get_Item(This,varIndex,pVal) ) 

#define IThinApp_VFolders_get_Count(This,pVal)	\
    ( (This)->lpVtbl -> get_Count(This,pVal) ) 

#define IThinApp_VFolders_get_length(This,pVal)	\
    ( (This)->lpVtbl -> get_length(This,pVal) ) 

#define IThinApp_VFolders_get__NewEnum(This,pVal)	\
    ( (This)->lpVtbl -> get__NewEnum(This,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_VFolders_INTERFACE_DEFINED__ */


#ifndef __IThinApp_VRegKeys_INTERFACE_DEFINED__
#define __IThinApp_VRegKeys_INTERFACE_DEFINED__

/* interface IThinApp_VRegKeys */
/* [object][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_VRegKeys;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("62A14BBB-01CB-4F59-956F-F726D47C3389")
    IThinApp_VRegKeys : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ const VARIANT varIndex,
            /* [retval][out] */ IThinApp_VRegKey **pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_length( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [hidden][restricted][id][propget] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown **pVal) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_VRegKeysVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_VRegKeys * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_VRegKeys * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_VRegKeys * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_VRegKeys * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_VRegKeys * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_VRegKeys * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_VRegKeys * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IThinApp_VRegKeys * This,
            /* [in] */ const VARIANT varIndex,
            /* [retval][out] */ IThinApp_VRegKey **pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IThinApp_VRegKeys * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_length )( 
            IThinApp_VRegKeys * This,
            /* [retval][out] */ long *pVal);
        
        /* [hidden][restricted][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get__NewEnum )( 
            IThinApp_VRegKeys * This,
            /* [retval][out] */ IUnknown **pVal);
        
        END_INTERFACE
    } IThinApp_VRegKeysVtbl;

    interface IThinApp_VRegKeys
    {
        CONST_VTBL struct IThinApp_VRegKeysVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_VRegKeys_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_VRegKeys_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_VRegKeys_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_VRegKeys_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_VRegKeys_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_VRegKeys_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_VRegKeys_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_VRegKeys_get_Item(This,varIndex,pVal)	\
    ( (This)->lpVtbl -> get_Item(This,varIndex,pVal) ) 

#define IThinApp_VRegKeys_get_Count(This,pVal)	\
    ( (This)->lpVtbl -> get_Count(This,pVal) ) 

#define IThinApp_VRegKeys_get_length(This,pVal)	\
    ( (This)->lpVtbl -> get_length(This,pVal) ) 

#define IThinApp_VRegKeys_get__NewEnum(This,pVal)	\
    ( (This)->lpVtbl -> get__NewEnum(This,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_VRegKeys_INTERFACE_DEFINED__ */


#ifndef __IThinApp_VFile_INTERFACE_DEFINED__
#define __IThinApp_VFile_INTERFACE_DEFINED__

/* interface IThinApp_VFile */
/* [object][nonextensible][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_VFile;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("ADF62A0D-982C-4DB9-A678-293183342124")
    IThinApp_VFile : public IDispatch
    {
    public:
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Attributes( 
            /* [retval][out] */ long *Attributes) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_DateCreated( 
            /* [retval][out] */ DATE *DateCreated) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_DateLastAccessed( 
            /* [retval][out] */ DATE *DateLastAccessed) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_DateLastModified( 
            /* [retval][out] */ DATE *DateLastModified) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_FileVersion( 
            /* [retval][out] */ BSTR *FileVersion) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_InternalName( 
            /* [retval][out] */ BSTR *InternalName) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Language( 
            /* [retval][out] */ BSTR *Language) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Manufacturer( 
            /* [retval][out] */ BSTR *Manufacturer) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR *Name) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ParentFolder( 
            /* [retval][out] */ IThinApp_VFolder **ParentFolder) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Path( 
            /* [retval][out] */ BSTR *Path) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ProductName( 
            /* [retval][out] */ BSTR *ProductName) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ProductVersion( 
            /* [retval][out] */ BSTR *ProductVersion) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ShortName( 
            /* [retval][out] */ BSTR *ShortName) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ShortPath( 
            /* [retval][out] */ BSTR *ShortPath) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Size( 
            /* [retval][out] */ MIDL_uhyper *Size) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_TranslationKey( 
            /* [retval][out] */ BSTR *TranslationKey) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Type( 
            /* [retval][out] */ BSTR *Type) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetHash( 
            /* [in] */ THINAPP_HASH_TYPE HashType,
            /* [retval][out] */ BSTR *Hash) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE VerifyContents( 
            /* [in] */ hyper Offset,
            /* [in] */ VARIANT Expected,
            THINAPP_VERIFYCONTENTS_TYPE MatchType,
            /* [retval][out] */ boolean *Matches) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_VFileVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_VFile * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_VFile * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_VFile * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_VFile * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_VFile * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_VFile * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_VFile * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Attributes )( 
            IThinApp_VFile * This,
            /* [retval][out] */ long *Attributes);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_DateCreated )( 
            IThinApp_VFile * This,
            /* [retval][out] */ DATE *DateCreated);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_DateLastAccessed )( 
            IThinApp_VFile * This,
            /* [retval][out] */ DATE *DateLastAccessed);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_DateLastModified )( 
            IThinApp_VFile * This,
            /* [retval][out] */ DATE *DateLastModified);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_FileVersion )( 
            IThinApp_VFile * This,
            /* [retval][out] */ BSTR *FileVersion);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_InternalName )( 
            IThinApp_VFile * This,
            /* [retval][out] */ BSTR *InternalName);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Language )( 
            IThinApp_VFile * This,
            /* [retval][out] */ BSTR *Language);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Manufacturer )( 
            IThinApp_VFile * This,
            /* [retval][out] */ BSTR *Manufacturer);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Name )( 
            IThinApp_VFile * This,
            /* [retval][out] */ BSTR *Name);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ParentFolder )( 
            IThinApp_VFile * This,
            /* [retval][out] */ IThinApp_VFolder **ParentFolder);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Path )( 
            IThinApp_VFile * This,
            /* [retval][out] */ BSTR *Path);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ProductName )( 
            IThinApp_VFile * This,
            /* [retval][out] */ BSTR *ProductName);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ProductVersion )( 
            IThinApp_VFile * This,
            /* [retval][out] */ BSTR *ProductVersion);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ShortName )( 
            IThinApp_VFile * This,
            /* [retval][out] */ BSTR *ShortName);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ShortPath )( 
            IThinApp_VFile * This,
            /* [retval][out] */ BSTR *ShortPath);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Size )( 
            IThinApp_VFile * This,
            /* [retval][out] */ MIDL_uhyper *Size);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_TranslationKey )( 
            IThinApp_VFile * This,
            /* [retval][out] */ BSTR *TranslationKey);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Type )( 
            IThinApp_VFile * This,
            /* [retval][out] */ BSTR *Type);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetHash )( 
            IThinApp_VFile * This,
            /* [in] */ THINAPP_HASH_TYPE HashType,
            /* [retval][out] */ BSTR *Hash);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *VerifyContents )( 
            IThinApp_VFile * This,
            /* [in] */ hyper Offset,
            /* [in] */ VARIANT Expected,
            THINAPP_VERIFYCONTENTS_TYPE MatchType,
            /* [retval][out] */ boolean *Matches);
        
        END_INTERFACE
    } IThinApp_VFileVtbl;

    interface IThinApp_VFile
    {
        CONST_VTBL struct IThinApp_VFileVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_VFile_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_VFile_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_VFile_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_VFile_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_VFile_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_VFile_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_VFile_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_VFile_get_Attributes(This,Attributes)	\
    ( (This)->lpVtbl -> get_Attributes(This,Attributes) ) 

#define IThinApp_VFile_get_DateCreated(This,DateCreated)	\
    ( (This)->lpVtbl -> get_DateCreated(This,DateCreated) ) 

#define IThinApp_VFile_get_DateLastAccessed(This,DateLastAccessed)	\
    ( (This)->lpVtbl -> get_DateLastAccessed(This,DateLastAccessed) ) 

#define IThinApp_VFile_get_DateLastModified(This,DateLastModified)	\
    ( (This)->lpVtbl -> get_DateLastModified(This,DateLastModified) ) 

#define IThinApp_VFile_get_FileVersion(This,FileVersion)	\
    ( (This)->lpVtbl -> get_FileVersion(This,FileVersion) ) 

#define IThinApp_VFile_get_InternalName(This,InternalName)	\
    ( (This)->lpVtbl -> get_InternalName(This,InternalName) ) 

#define IThinApp_VFile_get_Language(This,Language)	\
    ( (This)->lpVtbl -> get_Language(This,Language) ) 

#define IThinApp_VFile_get_Manufacturer(This,Manufacturer)	\
    ( (This)->lpVtbl -> get_Manufacturer(This,Manufacturer) ) 

#define IThinApp_VFile_get_Name(This,Name)	\
    ( (This)->lpVtbl -> get_Name(This,Name) ) 

#define IThinApp_VFile_get_ParentFolder(This,ParentFolder)	\
    ( (This)->lpVtbl -> get_ParentFolder(This,ParentFolder) ) 

#define IThinApp_VFile_get_Path(This,Path)	\
    ( (This)->lpVtbl -> get_Path(This,Path) ) 

#define IThinApp_VFile_get_ProductName(This,ProductName)	\
    ( (This)->lpVtbl -> get_ProductName(This,ProductName) ) 

#define IThinApp_VFile_get_ProductVersion(This,ProductVersion)	\
    ( (This)->lpVtbl -> get_ProductVersion(This,ProductVersion) ) 

#define IThinApp_VFile_get_ShortName(This,ShortName)	\
    ( (This)->lpVtbl -> get_ShortName(This,ShortName) ) 

#define IThinApp_VFile_get_ShortPath(This,ShortPath)	\
    ( (This)->lpVtbl -> get_ShortPath(This,ShortPath) ) 

#define IThinApp_VFile_get_Size(This,Size)	\
    ( (This)->lpVtbl -> get_Size(This,Size) ) 

#define IThinApp_VFile_get_TranslationKey(This,TranslationKey)	\
    ( (This)->lpVtbl -> get_TranslationKey(This,TranslationKey) ) 

#define IThinApp_VFile_get_Type(This,Type)	\
    ( (This)->lpVtbl -> get_Type(This,Type) ) 

#define IThinApp_VFile_GetHash(This,HashType,Hash)	\
    ( (This)->lpVtbl -> GetHash(This,HashType,Hash) ) 

#define IThinApp_VFile_VerifyContents(This,Offset,Expected,MatchType,Matches)	\
    ( (This)->lpVtbl -> VerifyContents(This,Offset,Expected,MatchType,Matches) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_VFile_INTERFACE_DEFINED__ */


#ifndef __IThinApp_VFiles_INTERFACE_DEFINED__
#define __IThinApp_VFiles_INTERFACE_DEFINED__

/* interface IThinApp_VFiles */
/* [object][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_VFiles;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4C23084D-48EF-410D-8493-A1FB5C1A2031")
    IThinApp_VFiles : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ const VARIANT varIndex,
            /* [retval][out] */ IThinApp_VFile **pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_length( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [hidden][restricted][id][propget] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown **pVal) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_VFilesVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_VFiles * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_VFiles * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_VFiles * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_VFiles * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_VFiles * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_VFiles * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_VFiles * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IThinApp_VFiles * This,
            /* [in] */ const VARIANT varIndex,
            /* [retval][out] */ IThinApp_VFile **pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IThinApp_VFiles * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_length )( 
            IThinApp_VFiles * This,
            /* [retval][out] */ long *pVal);
        
        /* [hidden][restricted][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get__NewEnum )( 
            IThinApp_VFiles * This,
            /* [retval][out] */ IUnknown **pVal);
        
        END_INTERFACE
    } IThinApp_VFilesVtbl;

    interface IThinApp_VFiles
    {
        CONST_VTBL struct IThinApp_VFilesVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_VFiles_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_VFiles_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_VFiles_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_VFiles_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_VFiles_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_VFiles_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_VFiles_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_VFiles_get_Item(This,varIndex,pVal)	\
    ( (This)->lpVtbl -> get_Item(This,varIndex,pVal) ) 

#define IThinApp_VFiles_get_Count(This,pVal)	\
    ( (This)->lpVtbl -> get_Count(This,pVal) ) 

#define IThinApp_VFiles_get_length(This,pVal)	\
    ( (This)->lpVtbl -> get_length(This,pVal) ) 

#define IThinApp_VFiles_get__NewEnum(This,pVal)	\
    ( (This)->lpVtbl -> get__NewEnum(This,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_VFiles_INTERFACE_DEFINED__ */


#ifndef __IThinApp_VFileSystemObject_INTERFACE_DEFINED__
#define __IThinApp_VFileSystemObject_INTERFACE_DEFINED__

/* interface IThinApp_VFileSystemObject */
/* [object][nonextensible][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_VFileSystemObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("7ADFD2AD-E19D-4B1E-9C71-ADBB474E3962")
    IThinApp_VFileSystemObject : public IDispatch
    {
    public:
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE BuildPath( 
            /* [in] */ BSTR OldPath,
            /* [in] */ BSTR Name,
            /* [retval][out] */ BSTR *NewPath) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE DriveExists( 
            /* [in] */ BSTR DriveSpec,
            /* [retval][out] */ boolean *Exists) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE FileExists( 
            /* [in] */ BSTR MacroFileSpec,
            /* [retval][out] */ boolean *Exists) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE FolderExists( 
            /* [in] */ BSTR MacroFileSpec,
            /* [retval][out] */ boolean *Exists) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetBaseName( 
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ BSTR *BaseName) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetExtensionName( 
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ BSTR *ExtensionName) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetFile( 
            /* [in] */ BSTR MacroFileSpec,
            /* [retval][out] */ IThinApp_VFile **File) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetFileName( 
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ BSTR *FileName) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetFileVersion( 
            /* [in] */ BSTR MacroFileSpec,
            /* [retval][out] */ BSTR *Version) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetFolder( 
            /* [in] */ BSTR MacroFileSpec,
            /* [retval][out] */ IThinApp_VFolder **Folder) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetParentFolderName( 
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ BSTR *ParentFolderName) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_VFileSystemObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_VFileSystemObject * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_VFileSystemObject * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_VFileSystemObject * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_VFileSystemObject * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *BuildPath )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ BSTR OldPath,
            /* [in] */ BSTR Name,
            /* [retval][out] */ BSTR *NewPath);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *DriveExists )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ BSTR DriveSpec,
            /* [retval][out] */ boolean *Exists);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *FileExists )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ BSTR MacroFileSpec,
            /* [retval][out] */ boolean *Exists);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *FolderExists )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ BSTR MacroFileSpec,
            /* [retval][out] */ boolean *Exists);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetBaseName )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ BSTR *BaseName);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetExtensionName )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ BSTR *ExtensionName);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetFile )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ BSTR MacroFileSpec,
            /* [retval][out] */ IThinApp_VFile **File);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetFileName )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ BSTR *FileName);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetFileVersion )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ BSTR MacroFileSpec,
            /* [retval][out] */ BSTR *Version);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetFolder )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ BSTR MacroFileSpec,
            /* [retval][out] */ IThinApp_VFolder **Folder);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetParentFolderName )( 
            IThinApp_VFileSystemObject * This,
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ BSTR *ParentFolderName);
        
        END_INTERFACE
    } IThinApp_VFileSystemObjectVtbl;

    interface IThinApp_VFileSystemObject
    {
        CONST_VTBL struct IThinApp_VFileSystemObjectVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_VFileSystemObject_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_VFileSystemObject_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_VFileSystemObject_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_VFileSystemObject_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_VFileSystemObject_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_VFileSystemObject_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_VFileSystemObject_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_VFileSystemObject_BuildPath(This,OldPath,Name,NewPath)	\
    ( (This)->lpVtbl -> BuildPath(This,OldPath,Name,NewPath) ) 

#define IThinApp_VFileSystemObject_DriveExists(This,DriveSpec,Exists)	\
    ( (This)->lpVtbl -> DriveExists(This,DriveSpec,Exists) ) 

#define IThinApp_VFileSystemObject_FileExists(This,MacroFileSpec,Exists)	\
    ( (This)->lpVtbl -> FileExists(This,MacroFileSpec,Exists) ) 

#define IThinApp_VFileSystemObject_FolderExists(This,MacroFileSpec,Exists)	\
    ( (This)->lpVtbl -> FolderExists(This,MacroFileSpec,Exists) ) 

#define IThinApp_VFileSystemObject_GetBaseName(This,FileSpec,BaseName)	\
    ( (This)->lpVtbl -> GetBaseName(This,FileSpec,BaseName) ) 

#define IThinApp_VFileSystemObject_GetExtensionName(This,FileSpec,ExtensionName)	\
    ( (This)->lpVtbl -> GetExtensionName(This,FileSpec,ExtensionName) ) 

#define IThinApp_VFileSystemObject_GetFile(This,MacroFileSpec,File)	\
    ( (This)->lpVtbl -> GetFile(This,MacroFileSpec,File) ) 

#define IThinApp_VFileSystemObject_GetFileName(This,FileSpec,FileName)	\
    ( (This)->lpVtbl -> GetFileName(This,FileSpec,FileName) ) 

#define IThinApp_VFileSystemObject_GetFileVersion(This,MacroFileSpec,Version)	\
    ( (This)->lpVtbl -> GetFileVersion(This,MacroFileSpec,Version) ) 

#define IThinApp_VFileSystemObject_GetFolder(This,MacroFileSpec,Folder)	\
    ( (This)->lpVtbl -> GetFolder(This,MacroFileSpec,Folder) ) 

#define IThinApp_VFileSystemObject_GetParentFolderName(This,FileSpec,ParentFolderName)	\
    ( (This)->lpVtbl -> GetParentFolderName(This,FileSpec,ParentFolderName) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_VFileSystemObject_INTERFACE_DEFINED__ */


#ifndef __IThinApp_VRegValue_INTERFACE_DEFINED__
#define __IThinApp_VRegValue_INTERFACE_DEFINED__

/* interface IThinApp_VRegValue */
/* [object][nonextensible][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_VRegValue;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D91E24D7-8824-4C3F-9F80-0AF851B20A38")
    IThinApp_VRegValue : public IDispatch
    {
    public:
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR *Name) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Type( 
            /* [retval][out] */ long *Type) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Data( 
            /* [retval][out] */ VARIANT *Value) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_VRegValueVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_VRegValue * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_VRegValue * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_VRegValue * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_VRegValue * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_VRegValue * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_VRegValue * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_VRegValue * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Name )( 
            IThinApp_VRegValue * This,
            /* [retval][out] */ BSTR *Name);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Type )( 
            IThinApp_VRegValue * This,
            /* [retval][out] */ long *Type);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Data )( 
            IThinApp_VRegValue * This,
            /* [retval][out] */ VARIANT *Value);
        
        END_INTERFACE
    } IThinApp_VRegValueVtbl;

    interface IThinApp_VRegValue
    {
        CONST_VTBL struct IThinApp_VRegValueVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_VRegValue_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_VRegValue_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_VRegValue_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_VRegValue_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_VRegValue_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_VRegValue_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_VRegValue_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_VRegValue_get_Name(This,Name)	\
    ( (This)->lpVtbl -> get_Name(This,Name) ) 

#define IThinApp_VRegValue_get_Type(This,Type)	\
    ( (This)->lpVtbl -> get_Type(This,Type) ) 

#define IThinApp_VRegValue_get_Data(This,Value)	\
    ( (This)->lpVtbl -> get_Data(This,Value) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_VRegValue_INTERFACE_DEFINED__ */


#ifndef __IThinApp_VRegValues_INTERFACE_DEFINED__
#define __IThinApp_VRegValues_INTERFACE_DEFINED__

/* interface IThinApp_VRegValues */
/* [object][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_VRegValues;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("76B5E3C9-7FE0-439C-8B34-F238A3953200")
    IThinApp_VRegValues : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ const VARIANT varIndex,
            /* [retval][out] */ IThinApp_VRegValue **pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_length( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [hidden][restricted][id][propget] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown **pVal) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_VRegValuesVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_VRegValues * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_VRegValues * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_VRegValues * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_VRegValues * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_VRegValues * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_VRegValues * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_VRegValues * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IThinApp_VRegValues * This,
            /* [in] */ const VARIANT varIndex,
            /* [retval][out] */ IThinApp_VRegValue **pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IThinApp_VRegValues * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_length )( 
            IThinApp_VRegValues * This,
            /* [retval][out] */ long *pVal);
        
        /* [hidden][restricted][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get__NewEnum )( 
            IThinApp_VRegValues * This,
            /* [retval][out] */ IUnknown **pVal);
        
        END_INTERFACE
    } IThinApp_VRegValuesVtbl;

    interface IThinApp_VRegValues
    {
        CONST_VTBL struct IThinApp_VRegValuesVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_VRegValues_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_VRegValues_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_VRegValues_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_VRegValues_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_VRegValues_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_VRegValues_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_VRegValues_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_VRegValues_get_Item(This,varIndex,pVal)	\
    ( (This)->lpVtbl -> get_Item(This,varIndex,pVal) ) 

#define IThinApp_VRegValues_get_Count(This,pVal)	\
    ( (This)->lpVtbl -> get_Count(This,pVal) ) 

#define IThinApp_VRegValues_get_length(This,pVal)	\
    ( (This)->lpVtbl -> get_length(This,pVal) ) 

#define IThinApp_VRegValues_get__NewEnum(This,pVal)	\
    ( (This)->lpVtbl -> get__NewEnum(This,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_VRegValues_INTERFACE_DEFINED__ */


#ifndef __IThinApp_VRegKey_INTERFACE_DEFINED__
#define __IThinApp_VRegKey_INTERFACE_DEFINED__

/* interface IThinApp_VRegKey */
/* [object][nonextensible][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_VRegKey;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("E4F15EA3-299B-4665-89BC-DCF8617F4030")
    IThinApp_VRegKey : public IDispatch
    {
    public:
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_SubKeys( 
            /* [retval][out] */ IThinApp_VRegKeys **SubKeys) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Values( 
            /* [retval][out] */ IThinApp_VRegValues **Values) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_VRegKeyVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_VRegKey * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_VRegKey * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_VRegKey * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_VRegKey * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_VRegKey * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_VRegKey * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_VRegKey * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_SubKeys )( 
            IThinApp_VRegKey * This,
            /* [retval][out] */ IThinApp_VRegKeys **SubKeys);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Values )( 
            IThinApp_VRegKey * This,
            /* [retval][out] */ IThinApp_VRegValues **Values);
        
        END_INTERFACE
    } IThinApp_VRegKeyVtbl;

    interface IThinApp_VRegKey
    {
        CONST_VTBL struct IThinApp_VRegKeyVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_VRegKey_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_VRegKey_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_VRegKey_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_VRegKey_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_VRegKey_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_VRegKey_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_VRegKey_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_VRegKey_get_SubKeys(This,SubKeys)	\
    ( (This)->lpVtbl -> get_SubKeys(This,SubKeys) ) 

#define IThinApp_VRegKey_get_Values(This,Values)	\
    ( (This)->lpVtbl -> get_Values(This,Values) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_VRegKey_INTERFACE_DEFINED__ */


#ifndef __IThinApp_VRegKey2_INTERFACE_DEFINED__
#define __IThinApp_VRegKey2_INTERFACE_DEFINED__

/* interface IThinApp_VRegKey2 */
/* [object][nonextensible][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_VRegKey2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("0E712873-42B4-4ECD-BAFE-B8F800576ED9")
    IThinApp_VRegKey2 : public IThinApp_VRegKey
    {
    public:
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR *Name) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_VRegKey2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_VRegKey2 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_VRegKey2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_VRegKey2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_VRegKey2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_VRegKey2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_VRegKey2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_VRegKey2 * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_SubKeys )( 
            IThinApp_VRegKey2 * This,
            /* [retval][out] */ IThinApp_VRegKeys **SubKeys);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Values )( 
            IThinApp_VRegKey2 * This,
            /* [retval][out] */ IThinApp_VRegValues **Values);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Name )( 
            IThinApp_VRegKey2 * This,
            /* [retval][out] */ BSTR *Name);
        
        END_INTERFACE
    } IThinApp_VRegKey2Vtbl;

    interface IThinApp_VRegKey2
    {
        CONST_VTBL struct IThinApp_VRegKey2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_VRegKey2_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_VRegKey2_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_VRegKey2_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_VRegKey2_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_VRegKey2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_VRegKey2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_VRegKey2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_VRegKey2_get_SubKeys(This,SubKeys)	\
    ( (This)->lpVtbl -> get_SubKeys(This,SubKeys) ) 

#define IThinApp_VRegKey2_get_Values(This,Values)	\
    ( (This)->lpVtbl -> get_Values(This,Values) ) 


#define IThinApp_VRegKey2_get_Name(This,Name)	\
    ( (This)->lpVtbl -> get_Name(This,Name) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_VRegKey2_INTERFACE_DEFINED__ */


#ifndef __IThinApp_VRegistryObject_INTERFACE_DEFINED__
#define __IThinApp_VRegistryObject_INTERFACE_DEFINED__

/* interface IThinApp_VRegistryObject */
/* [object][nonextensible][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_VRegistryObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("CB7383C6-9F9F-47C1-8F06-C4E3997BE652")
    IThinApp_VRegistryObject : public IDispatch
    {
    public:
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE OpenKey( 
            /* [in] */ BSTR Base,
            /* [in] */ BSTR KeyPath,
            /* [retval][out] */ IThinApp_VRegKey **Key) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_VRegistryObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_VRegistryObject * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_VRegistryObject * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_VRegistryObject * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_VRegistryObject * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_VRegistryObject * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_VRegistryObject * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_VRegistryObject * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *OpenKey )( 
            IThinApp_VRegistryObject * This,
            /* [in] */ BSTR Base,
            /* [in] */ BSTR KeyPath,
            /* [retval][out] */ IThinApp_VRegKey **Key);
        
        END_INTERFACE
    } IThinApp_VRegistryObjectVtbl;

    interface IThinApp_VRegistryObject
    {
        CONST_VTBL struct IThinApp_VRegistryObjectVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_VRegistryObject_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_VRegistryObject_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_VRegistryObject_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_VRegistryObject_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_VRegistryObject_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_VRegistryObject_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_VRegistryObject_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_VRegistryObject_OpenKey(This,Base,KeyPath,Key)	\
    ( (This)->lpVtbl -> OpenKey(This,Base,KeyPath,Key) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_VRegistryObject_INTERFACE_DEFINED__ */


#ifndef __IThinApp_Option_INTERFACE_DEFINED__
#define __IThinApp_Option_INTERFACE_DEFINED__

/* interface IThinApp_Option */
/* [object][nonextensible][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_Option;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("FCAE9FBF-FB9E-4BE0-A53A-104FC1DFBEB6")
    IThinApp_Option : public IDispatch
    {
    public:
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR *Name) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Value( 
            /* [retval][out] */ BSTR *Value) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_OptionVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_Option * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_Option * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_Option * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_Option * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_Option * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_Option * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_Option * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Name )( 
            IThinApp_Option * This,
            /* [retval][out] */ BSTR *Name);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Value )( 
            IThinApp_Option * This,
            /* [retval][out] */ BSTR *Value);
        
        END_INTERFACE
    } IThinApp_OptionVtbl;

    interface IThinApp_Option
    {
        CONST_VTBL struct IThinApp_OptionVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_Option_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_Option_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_Option_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_Option_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_Option_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_Option_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_Option_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_Option_get_Name(This,Name)	\
    ( (This)->lpVtbl -> get_Name(This,Name) ) 

#define IThinApp_Option_get_Value(This,Value)	\
    ( (This)->lpVtbl -> get_Value(This,Value) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_Option_INTERFACE_DEFINED__ */


#ifndef __IThinApp_Options_INTERFACE_DEFINED__
#define __IThinApp_Options_INTERFACE_DEFINED__

/* interface IThinApp_Options */
/* [object][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_Options;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F4ED0ED0-962C-4734-9608-92820C89C573")
    IThinApp_Options : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ const VARIANT varIndex,
            /* [retval][out] */ IThinApp_Option **pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_length( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [hidden][restricted][id][propget] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown **pVal) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_OptionsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_Options * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_Options * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_Options * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_Options * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_Options * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_Options * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_Options * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IThinApp_Options * This,
            /* [in] */ const VARIANT varIndex,
            /* [retval][out] */ IThinApp_Option **pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IThinApp_Options * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_length )( 
            IThinApp_Options * This,
            /* [retval][out] */ long *pVal);
        
        /* [hidden][restricted][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get__NewEnum )( 
            IThinApp_Options * This,
            /* [retval][out] */ IUnknown **pVal);
        
        END_INTERFACE
    } IThinApp_OptionsVtbl;

    interface IThinApp_Options
    {
        CONST_VTBL struct IThinApp_OptionsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_Options_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_Options_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_Options_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_Options_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_Options_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_Options_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_Options_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_Options_get_Item(This,varIndex,pVal)	\
    ( (This)->lpVtbl -> get_Item(This,varIndex,pVal) ) 

#define IThinApp_Options_get_Count(This,pVal)	\
    ( (This)->lpVtbl -> get_Count(This,pVal) ) 

#define IThinApp_Options_get_length(This,pVal)	\
    ( (This)->lpVtbl -> get_length(This,pVal) ) 

#define IThinApp_Options_get__NewEnum(This,pVal)	\
    ( (This)->lpVtbl -> get__NewEnum(This,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_Options_INTERFACE_DEFINED__ */


#ifndef __IThinApp_Package_INTERFACE_DEFINED__
#define __IThinApp_Package_INTERFACE_DEFINED__

/* interface IThinApp_Package */
/* [object][nonextensible][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_Package;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B8A7A75F-867F-42C5-9645-ACEC7FCAE91D")
    IThinApp_Package : public IDispatch
    {
    public:
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_InventoryName( 
            /* [retval][out] */ BSTR *InventoryName) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_MainDataContainer( 
            /* [retval][out] */ BSTR *MainDataContainer) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_MSIVersion( 
            /* [retval][out] */ BSTR *MSIVersion) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ThinAppType( 
            /* [retval][out] */ THINAPP_TYPE *ThinAppType) = 0;
        
        virtual /* [id][helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ThinAppVersion( 
            /* [retval][out] */ BSTR *ThinAppVersion) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE AppSyncUpdateAvailable( 
            /* [in] */ VARIANT AppSyncURL,
            /* [retval][out] */ boolean *Available) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetOptions( 
            /* [retval][out] */ IThinApp_Options **Options) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetOptionalAppLinks( 
            /* [in] */ BSTR AppLinkPath,
            /* [retval][out] */ IThinApp_Packages **OptionalAppLinks) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetRequiredAppLinks( 
            /* [in] */ BSTR AppLinkPath,
            /* [retval][out] */ IThinApp_Packages **RequiredAppLinks) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetShortcutList( 
            /* [retval][out] */ BSTR *ShortcutList) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetVFileSystemObject( 
            /* [in] */ long Reserved,
            /* [retval][out] */ IThinApp_VFileSystemObject **VFileSystemObject) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetVRegistryObject( 
            /* [in] */ long Reserved,
            /* [retval][out] */ IThinApp_VRegistryObject **VRegistryObject) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE MacroToPath( 
            /* [in] */ BSTR MacroFileSpec,
            /* [retval][out] */ BSTR *FileSpec) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE PathToMacro( 
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ BSTR *MacroFileSpec) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE RetrieveIcon( 
            /* [in] */ BSTR IconFileName,
            /* [in] */ VARIANT FileName) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE Install( 
            /* [in] */ VARIANT InstallDir,
            /* [in] */ long Flags) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE Register( 
            /* [in] */ long Flags) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE Unregister( void) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE Uninstall( void) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE AppSync( 
            /* [in] */ long Flags,
            /* [in] */ VARIANT AppSyncURL) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_PackageVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_Package * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_Package * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_Package * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_Package * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_Package * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_Package * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_Package * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_InventoryName )( 
            IThinApp_Package * This,
            /* [retval][out] */ BSTR *InventoryName);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MainDataContainer )( 
            IThinApp_Package * This,
            /* [retval][out] */ BSTR *MainDataContainer);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MSIVersion )( 
            IThinApp_Package * This,
            /* [retval][out] */ BSTR *MSIVersion);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ThinAppType )( 
            IThinApp_Package * This,
            /* [retval][out] */ THINAPP_TYPE *ThinAppType);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ThinAppVersion )( 
            IThinApp_Package * This,
            /* [retval][out] */ BSTR *ThinAppVersion);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *AppSyncUpdateAvailable )( 
            IThinApp_Package * This,
            /* [in] */ VARIANT AppSyncURL,
            /* [retval][out] */ boolean *Available);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetOptions )( 
            IThinApp_Package * This,
            /* [retval][out] */ IThinApp_Options **Options);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetOptionalAppLinks )( 
            IThinApp_Package * This,
            /* [in] */ BSTR AppLinkPath,
            /* [retval][out] */ IThinApp_Packages **OptionalAppLinks);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetRequiredAppLinks )( 
            IThinApp_Package * This,
            /* [in] */ BSTR AppLinkPath,
            /* [retval][out] */ IThinApp_Packages **RequiredAppLinks);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetShortcutList )( 
            IThinApp_Package * This,
            /* [retval][out] */ BSTR *ShortcutList);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetVFileSystemObject )( 
            IThinApp_Package * This,
            /* [in] */ long Reserved,
            /* [retval][out] */ IThinApp_VFileSystemObject **VFileSystemObject);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetVRegistryObject )( 
            IThinApp_Package * This,
            /* [in] */ long Reserved,
            /* [retval][out] */ IThinApp_VRegistryObject **VRegistryObject);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *MacroToPath )( 
            IThinApp_Package * This,
            /* [in] */ BSTR MacroFileSpec,
            /* [retval][out] */ BSTR *FileSpec);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *PathToMacro )( 
            IThinApp_Package * This,
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ BSTR *MacroFileSpec);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *RetrieveIcon )( 
            IThinApp_Package * This,
            /* [in] */ BSTR IconFileName,
            /* [in] */ VARIANT FileName);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *Install )( 
            IThinApp_Package * This,
            /* [in] */ VARIANT InstallDir,
            /* [in] */ long Flags);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *Register )( 
            IThinApp_Package * This,
            /* [in] */ long Flags);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *Unregister )( 
            IThinApp_Package * This);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *Uninstall )( 
            IThinApp_Package * This);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *AppSync )( 
            IThinApp_Package * This,
            /* [in] */ long Flags,
            /* [in] */ VARIANT AppSyncURL);
        
        END_INTERFACE
    } IThinApp_PackageVtbl;

    interface IThinApp_Package
    {
        CONST_VTBL struct IThinApp_PackageVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_Package_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_Package_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_Package_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_Package_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_Package_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_Package_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_Package_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_Package_get_InventoryName(This,InventoryName)	\
    ( (This)->lpVtbl -> get_InventoryName(This,InventoryName) ) 

#define IThinApp_Package_get_MainDataContainer(This,MainDataContainer)	\
    ( (This)->lpVtbl -> get_MainDataContainer(This,MainDataContainer) ) 

#define IThinApp_Package_get_MSIVersion(This,MSIVersion)	\
    ( (This)->lpVtbl -> get_MSIVersion(This,MSIVersion) ) 

#define IThinApp_Package_get_ThinAppType(This,ThinAppType)	\
    ( (This)->lpVtbl -> get_ThinAppType(This,ThinAppType) ) 

#define IThinApp_Package_get_ThinAppVersion(This,ThinAppVersion)	\
    ( (This)->lpVtbl -> get_ThinAppVersion(This,ThinAppVersion) ) 

#define IThinApp_Package_AppSyncUpdateAvailable(This,AppSyncURL,Available)	\
    ( (This)->lpVtbl -> AppSyncUpdateAvailable(This,AppSyncURL,Available) ) 

#define IThinApp_Package_GetOptions(This,Options)	\
    ( (This)->lpVtbl -> GetOptions(This,Options) ) 

#define IThinApp_Package_GetOptionalAppLinks(This,AppLinkPath,OptionalAppLinks)	\
    ( (This)->lpVtbl -> GetOptionalAppLinks(This,AppLinkPath,OptionalAppLinks) ) 

#define IThinApp_Package_GetRequiredAppLinks(This,AppLinkPath,RequiredAppLinks)	\
    ( (This)->lpVtbl -> GetRequiredAppLinks(This,AppLinkPath,RequiredAppLinks) ) 

#define IThinApp_Package_GetShortcutList(This,ShortcutList)	\
    ( (This)->lpVtbl -> GetShortcutList(This,ShortcutList) ) 

#define IThinApp_Package_GetVFileSystemObject(This,Reserved,VFileSystemObject)	\
    ( (This)->lpVtbl -> GetVFileSystemObject(This,Reserved,VFileSystemObject) ) 

#define IThinApp_Package_GetVRegistryObject(This,Reserved,VRegistryObject)	\
    ( (This)->lpVtbl -> GetVRegistryObject(This,Reserved,VRegistryObject) ) 

#define IThinApp_Package_MacroToPath(This,MacroFileSpec,FileSpec)	\
    ( (This)->lpVtbl -> MacroToPath(This,MacroFileSpec,FileSpec) ) 

#define IThinApp_Package_PathToMacro(This,FileSpec,MacroFileSpec)	\
    ( (This)->lpVtbl -> PathToMacro(This,FileSpec,MacroFileSpec) ) 

#define IThinApp_Package_RetrieveIcon(This,IconFileName,FileName)	\
    ( (This)->lpVtbl -> RetrieveIcon(This,IconFileName,FileName) ) 

#define IThinApp_Package_Install(This,InstallDir,Flags)	\
    ( (This)->lpVtbl -> Install(This,InstallDir,Flags) ) 

#define IThinApp_Package_Register(This,Flags)	\
    ( (This)->lpVtbl -> Register(This,Flags) ) 

#define IThinApp_Package_Unregister(This)	\
    ( (This)->lpVtbl -> Unregister(This) ) 

#define IThinApp_Package_Uninstall(This)	\
    ( (This)->lpVtbl -> Uninstall(This) ) 

#define IThinApp_Package_AppSync(This,Flags,AppSyncURL)	\
    ( (This)->lpVtbl -> AppSync(This,Flags,AppSyncURL) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_Package_INTERFACE_DEFINED__ */


#ifndef __IThinApp_Package2_INTERFACE_DEFINED__
#define __IThinApp_Package2_INTERFACE_DEFINED__

/* interface IThinApp_Package2 */
/* [object][nonextensible][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_Package2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("99FDBA5F-1E98-4725-ABBB-51016B2ABA9C")
    IThinApp_Package2 : public IThinApp_Package
    {
    public:
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE UnregisterEx( 
            /* [in] */ long Flags) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_Package2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_Package2 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_Package2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_Package2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_Package2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_Package2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_Package2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_Package2 * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_InventoryName )( 
            IThinApp_Package2 * This,
            /* [retval][out] */ BSTR *InventoryName);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MainDataContainer )( 
            IThinApp_Package2 * This,
            /* [retval][out] */ BSTR *MainDataContainer);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MSIVersion )( 
            IThinApp_Package2 * This,
            /* [retval][out] */ BSTR *MSIVersion);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ThinAppType )( 
            IThinApp_Package2 * This,
            /* [retval][out] */ THINAPP_TYPE *ThinAppType);
        
        /* [id][helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ThinAppVersion )( 
            IThinApp_Package2 * This,
            /* [retval][out] */ BSTR *ThinAppVersion);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *AppSyncUpdateAvailable )( 
            IThinApp_Package2 * This,
            /* [in] */ VARIANT AppSyncURL,
            /* [retval][out] */ boolean *Available);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetOptions )( 
            IThinApp_Package2 * This,
            /* [retval][out] */ IThinApp_Options **Options);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetOptionalAppLinks )( 
            IThinApp_Package2 * This,
            /* [in] */ BSTR AppLinkPath,
            /* [retval][out] */ IThinApp_Packages **OptionalAppLinks);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetRequiredAppLinks )( 
            IThinApp_Package2 * This,
            /* [in] */ BSTR AppLinkPath,
            /* [retval][out] */ IThinApp_Packages **RequiredAppLinks);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetShortcutList )( 
            IThinApp_Package2 * This,
            /* [retval][out] */ BSTR *ShortcutList);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetVFileSystemObject )( 
            IThinApp_Package2 * This,
            /* [in] */ long Reserved,
            /* [retval][out] */ IThinApp_VFileSystemObject **VFileSystemObject);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetVRegistryObject )( 
            IThinApp_Package2 * This,
            /* [in] */ long Reserved,
            /* [retval][out] */ IThinApp_VRegistryObject **VRegistryObject);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *MacroToPath )( 
            IThinApp_Package2 * This,
            /* [in] */ BSTR MacroFileSpec,
            /* [retval][out] */ BSTR *FileSpec);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *PathToMacro )( 
            IThinApp_Package2 * This,
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ BSTR *MacroFileSpec);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *RetrieveIcon )( 
            IThinApp_Package2 * This,
            /* [in] */ BSTR IconFileName,
            /* [in] */ VARIANT FileName);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *Install )( 
            IThinApp_Package2 * This,
            /* [in] */ VARIANT InstallDir,
            /* [in] */ long Flags);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *Register )( 
            IThinApp_Package2 * This,
            /* [in] */ long Flags);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *Unregister )( 
            IThinApp_Package2 * This);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *Uninstall )( 
            IThinApp_Package2 * This);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *AppSync )( 
            IThinApp_Package2 * This,
            /* [in] */ long Flags,
            /* [in] */ VARIANT AppSyncURL);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *UnregisterEx )( 
            IThinApp_Package2 * This,
            /* [in] */ long Flags);
        
        END_INTERFACE
    } IThinApp_Package2Vtbl;

    interface IThinApp_Package2
    {
        CONST_VTBL struct IThinApp_Package2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_Package2_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_Package2_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_Package2_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_Package2_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_Package2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_Package2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_Package2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_Package2_get_InventoryName(This,InventoryName)	\
    ( (This)->lpVtbl -> get_InventoryName(This,InventoryName) ) 

#define IThinApp_Package2_get_MainDataContainer(This,MainDataContainer)	\
    ( (This)->lpVtbl -> get_MainDataContainer(This,MainDataContainer) ) 

#define IThinApp_Package2_get_MSIVersion(This,MSIVersion)	\
    ( (This)->lpVtbl -> get_MSIVersion(This,MSIVersion) ) 

#define IThinApp_Package2_get_ThinAppType(This,ThinAppType)	\
    ( (This)->lpVtbl -> get_ThinAppType(This,ThinAppType) ) 

#define IThinApp_Package2_get_ThinAppVersion(This,ThinAppVersion)	\
    ( (This)->lpVtbl -> get_ThinAppVersion(This,ThinAppVersion) ) 

#define IThinApp_Package2_AppSyncUpdateAvailable(This,AppSyncURL,Available)	\
    ( (This)->lpVtbl -> AppSyncUpdateAvailable(This,AppSyncURL,Available) ) 

#define IThinApp_Package2_GetOptions(This,Options)	\
    ( (This)->lpVtbl -> GetOptions(This,Options) ) 

#define IThinApp_Package2_GetOptionalAppLinks(This,AppLinkPath,OptionalAppLinks)	\
    ( (This)->lpVtbl -> GetOptionalAppLinks(This,AppLinkPath,OptionalAppLinks) ) 

#define IThinApp_Package2_GetRequiredAppLinks(This,AppLinkPath,RequiredAppLinks)	\
    ( (This)->lpVtbl -> GetRequiredAppLinks(This,AppLinkPath,RequiredAppLinks) ) 

#define IThinApp_Package2_GetShortcutList(This,ShortcutList)	\
    ( (This)->lpVtbl -> GetShortcutList(This,ShortcutList) ) 

#define IThinApp_Package2_GetVFileSystemObject(This,Reserved,VFileSystemObject)	\
    ( (This)->lpVtbl -> GetVFileSystemObject(This,Reserved,VFileSystemObject) ) 

#define IThinApp_Package2_GetVRegistryObject(This,Reserved,VRegistryObject)	\
    ( (This)->lpVtbl -> GetVRegistryObject(This,Reserved,VRegistryObject) ) 

#define IThinApp_Package2_MacroToPath(This,MacroFileSpec,FileSpec)	\
    ( (This)->lpVtbl -> MacroToPath(This,MacroFileSpec,FileSpec) ) 

#define IThinApp_Package2_PathToMacro(This,FileSpec,MacroFileSpec)	\
    ( (This)->lpVtbl -> PathToMacro(This,FileSpec,MacroFileSpec) ) 

#define IThinApp_Package2_RetrieveIcon(This,IconFileName,FileName)	\
    ( (This)->lpVtbl -> RetrieveIcon(This,IconFileName,FileName) ) 

#define IThinApp_Package2_Install(This,InstallDir,Flags)	\
    ( (This)->lpVtbl -> Install(This,InstallDir,Flags) ) 

#define IThinApp_Package2_Register(This,Flags)	\
    ( (This)->lpVtbl -> Register(This,Flags) ) 

#define IThinApp_Package2_Unregister(This)	\
    ( (This)->lpVtbl -> Unregister(This) ) 

#define IThinApp_Package2_Uninstall(This)	\
    ( (This)->lpVtbl -> Uninstall(This) ) 

#define IThinApp_Package2_AppSync(This,Flags,AppSyncURL)	\
    ( (This)->lpVtbl -> AppSync(This,Flags,AppSyncURL) ) 


#define IThinApp_Package2_UnregisterEx(This,Flags)	\
    ( (This)->lpVtbl -> UnregisterEx(This,Flags) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_Package2_INTERFACE_DEFINED__ */


#ifndef __IThinApp_Management_INTERFACE_DEFINED__
#define __IThinApp_Management_INTERFACE_DEFINED__

/* interface IThinApp_Management */
/* [object][nonextensible][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_Management;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6D52EC83-0257-418C-9F18-B3AB13D2E90D")
    IThinApp_Management : public IDispatch
    {
    public:
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE GetThinAppType( 
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ THINAPP_TYPE *ThinAppType) = 0;
        
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE OpenPackage( 
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ IThinApp_Package **Package) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_ManagementVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_Management * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_Management * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_Management * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_Management * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_Management * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_Management * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_Management * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetThinAppType )( 
            IThinApp_Management * This,
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ THINAPP_TYPE *ThinAppType);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *OpenPackage )( 
            IThinApp_Management * This,
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ IThinApp_Package **Package);
        
        END_INTERFACE
    } IThinApp_ManagementVtbl;

    interface IThinApp_Management
    {
        CONST_VTBL struct IThinApp_ManagementVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_Management_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_Management_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_Management_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_Management_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_Management_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_Management_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_Management_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_Management_GetThinAppType(This,FileSpec,ThinAppType)	\
    ( (This)->lpVtbl -> GetThinAppType(This,FileSpec,ThinAppType) ) 

#define IThinApp_Management_OpenPackage(This,FileSpec,Package)	\
    ( (This)->lpVtbl -> OpenPackage(This,FileSpec,Package) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_Management_INTERFACE_DEFINED__ */


#ifndef __IThinApp_Management2_INTERFACE_DEFINED__
#define __IThinApp_Management2_INTERFACE_DEFINED__

/* interface IThinApp_Management2 */
/* [object][nonextensible][dual][oleautomation][uuid] */ 


EXTERN_C const IID IID_IThinApp_Management2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D209B6C0-B58A-43E6-BD7A-581AFCF3A055")
    IThinApp_Management2 : public IThinApp_Management
    {
    public:
        virtual /* [id][helpstring] */ HRESULT STDMETHODCALLTYPE RefreshDesktop( void) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinApp_Management2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinApp_Management2 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinApp_Management2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinApp_Management2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThinApp_Management2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThinApp_Management2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThinApp_Management2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThinApp_Management2 * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetThinAppType )( 
            IThinApp_Management2 * This,
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ THINAPP_TYPE *ThinAppType);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *OpenPackage )( 
            IThinApp_Management2 * This,
            /* [in] */ BSTR FileSpec,
            /* [retval][out] */ IThinApp_Package **Package);
        
        /* [id][helpstring] */ HRESULT ( STDMETHODCALLTYPE *RefreshDesktop )( 
            IThinApp_Management2 * This);
        
        END_INTERFACE
    } IThinApp_Management2Vtbl;

    interface IThinApp_Management2
    {
        CONST_VTBL struct IThinApp_Management2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinApp_Management2_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinApp_Management2_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinApp_Management2_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinApp_Management2_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThinApp_Management2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThinApp_Management2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThinApp_Management2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThinApp_Management2_GetThinAppType(This,FileSpec,ThinAppType)	\
    ( (This)->lpVtbl -> GetThinAppType(This,FileSpec,ThinAppType) ) 

#define IThinApp_Management2_OpenPackage(This,FileSpec,Package)	\
    ( (This)->lpVtbl -> OpenPackage(This,FileSpec,Package) ) 


#define IThinApp_Management2_RefreshDesktop(This)	\
    ( (This)->lpVtbl -> RefreshDesktop(This) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinApp_Management2_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_CThinApp_Management;

#ifdef __cplusplus

class DECLSPEC_UUID("86CB2272-319C-46AC-96DA-430D26EAF6A0")
CThinApp_Management;
#endif

#ifndef __IThinstallLegacyApi_INTERFACE_DEFINED__
#define __IThinstallLegacyApi_INTERFACE_DEFINED__

/* interface IThinstallLegacyApi */
/* [object][uuid] */ 


EXTERN_C const IID IID_IThinstallLegacyApi;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6719C5C1-938D-4100-AAA9-1305D15D9154")
    IThinstallLegacyApi : public IClassFactory
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE CreateTextRegistryFile( 
            LPCWSTR ProjectLocation,
            HKEY base,
            HANDLE *UnicodeTextFile) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE WriteRegistrySubkeyFromMacrovisionsprintf( 
            HANDLE UnicodeTextFile,
            LPCWSTR Subkey,
            IsolationModeType Isolation) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE WriteRegistryValueFromMacrovisionsprintf( 
            HANDLE UnicodeTextFile,
            LPCWSTR ValueName,
            DWORD ValueType,
            LPCWSTR ValueData) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CloseTextRegistryFile( 
            HANDLE UnicodeTextFile) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetPackageInfo( 
            LPCWSTR ExePackage,
            ThinstallPackageInfo *Info,
            DWORD *InfoSizeInBytes) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE LocateSandBoxPath( 
            LPCWSTR ExePackage,
            LPWSTR ReturnedPath,
            DWORD *ReturnedPathSizeInChars,
            DWORD *StatusFlags) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetProcessInfo( 
            DWORD ProcessID,
            LPWSTR Module0Filename,
            DWORD Module0FilenameSizeInChars,
            LPWSTR PackageFilename,
            DWORD PackageFilenameSizeInChars,
            LPWSTR StartEXEFilename,
            DWORD StartEXEFilenameSizeInChars,
            LPWSTR StartWorkingDirectory,
            DWORD StartWorkingDirectorySizeInChars) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IThinstallLegacyApiVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThinstallLegacyApi * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThinstallLegacyApi * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThinstallLegacyApi * This);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *CreateInstance )( 
            IThinstallLegacyApi * This,
            /* [annotation][unique][in] */ 
            _In_opt_  IUnknown *pUnkOuter,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *LockServer )( 
            IThinstallLegacyApi * This,
            /* [in] */ BOOL fLock);
        
        HRESULT ( STDMETHODCALLTYPE *CreateTextRegistryFile )( 
            IThinstallLegacyApi * This,
            LPCWSTR ProjectLocation,
            HKEY base,
            HANDLE *UnicodeTextFile);
        
        HRESULT ( STDMETHODCALLTYPE *WriteRegistrySubkeyFromMacrovisionsprintf )( 
            IThinstallLegacyApi * This,
            HANDLE UnicodeTextFile,
            LPCWSTR Subkey,
            IsolationModeType Isolation);
        
        HRESULT ( STDMETHODCALLTYPE *WriteRegistryValueFromMacrovisionsprintf )( 
            IThinstallLegacyApi * This,
            HANDLE UnicodeTextFile,
            LPCWSTR ValueName,
            DWORD ValueType,
            LPCWSTR ValueData);
        
        HRESULT ( STDMETHODCALLTYPE *CloseTextRegistryFile )( 
            IThinstallLegacyApi * This,
            HANDLE UnicodeTextFile);
        
        HRESULT ( STDMETHODCALLTYPE *GetPackageInfo )( 
            IThinstallLegacyApi * This,
            LPCWSTR ExePackage,
            ThinstallPackageInfo *Info,
            DWORD *InfoSizeInBytes);
        
        HRESULT ( STDMETHODCALLTYPE *LocateSandBoxPath )( 
            IThinstallLegacyApi * This,
            LPCWSTR ExePackage,
            LPWSTR ReturnedPath,
            DWORD *ReturnedPathSizeInChars,
            DWORD *StatusFlags);
        
        HRESULT ( STDMETHODCALLTYPE *GetProcessInfo )( 
            IThinstallLegacyApi * This,
            DWORD ProcessID,
            LPWSTR Module0Filename,
            DWORD Module0FilenameSizeInChars,
            LPWSTR PackageFilename,
            DWORD PackageFilenameSizeInChars,
            LPWSTR StartEXEFilename,
            DWORD StartEXEFilenameSizeInChars,
            LPWSTR StartWorkingDirectory,
            DWORD StartWorkingDirectorySizeInChars);
        
        END_INTERFACE
    } IThinstallLegacyApiVtbl;

    interface IThinstallLegacyApi
    {
        CONST_VTBL struct IThinstallLegacyApiVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThinstallLegacyApi_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThinstallLegacyApi_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThinstallLegacyApi_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThinstallLegacyApi_CreateInstance(This,pUnkOuter,riid,ppvObject)	\
    ( (This)->lpVtbl -> CreateInstance(This,pUnkOuter,riid,ppvObject) ) 

#define IThinstallLegacyApi_LockServer(This,fLock)	\
    ( (This)->lpVtbl -> LockServer(This,fLock) ) 


#define IThinstallLegacyApi_CreateTextRegistryFile(This,ProjectLocation,base,UnicodeTextFile)	\
    ( (This)->lpVtbl -> CreateTextRegistryFile(This,ProjectLocation,base,UnicodeTextFile) ) 

#define IThinstallLegacyApi_WriteRegistrySubkeyFromMacrovisionsprintf(This,UnicodeTextFile,Subkey,Isolation)	\
    ( (This)->lpVtbl -> WriteRegistrySubkeyFromMacrovisionsprintf(This,UnicodeTextFile,Subkey,Isolation) ) 

#define IThinstallLegacyApi_WriteRegistryValueFromMacrovisionsprintf(This,UnicodeTextFile,ValueName,ValueType,ValueData)	\
    ( (This)->lpVtbl -> WriteRegistryValueFromMacrovisionsprintf(This,UnicodeTextFile,ValueName,ValueType,ValueData) ) 

#define IThinstallLegacyApi_CloseTextRegistryFile(This,UnicodeTextFile)	\
    ( (This)->lpVtbl -> CloseTextRegistryFile(This,UnicodeTextFile) ) 

#define IThinstallLegacyApi_GetPackageInfo(This,ExePackage,Info,InfoSizeInBytes)	\
    ( (This)->lpVtbl -> GetPackageInfo(This,ExePackage,Info,InfoSizeInBytes) ) 

#define IThinstallLegacyApi_LocateSandBoxPath(This,ExePackage,ReturnedPath,ReturnedPathSizeInChars,StatusFlags)	\
    ( (This)->lpVtbl -> LocateSandBoxPath(This,ExePackage,ReturnedPath,ReturnedPathSizeInChars,StatusFlags) ) 

#define IThinstallLegacyApi_GetProcessInfo(This,ProcessID,Module0Filename,Module0FilenameSizeInChars,PackageFilename,PackageFilenameSizeInChars,StartEXEFilename,StartEXEFilenameSizeInChars,StartWorkingDirectory,StartWorkingDirectorySizeInChars)	\
    ( (This)->lpVtbl -> GetProcessInfo(This,ProcessID,Module0Filename,Module0FilenameSizeInChars,PackageFilename,PackageFilenameSizeInChars,StartEXEFilename,StartEXEFilenameSizeInChars,StartWorkingDirectory,StartWorkingDirectorySizeInChars) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThinstallLegacyApi_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_CThinstallLegacyApi;

#ifdef __cplusplus

class DECLSPEC_UUID("B52567E6-42B8-4f24-86E0-85FAB7C2CBB3")
CThinstallLegacyApi;
#endif
#endif /* __ThinAppSDK_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


